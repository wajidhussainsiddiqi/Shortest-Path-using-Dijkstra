
package graph;
/**
 * This class is used to create a NodeObject for the Graph  
 * 
 * @author Wajid Hussain
 * @version 1.0
 * @since   2016-06-4
 */
public class Node {
    
    private final String    nodeName;
    private final int     locationX;
    private final int     locationY;
    /**
     * Default constructor
     * 
     * @param newLocationX  location on the x axis
     * @param newLocationY  location on the y axis
     * @param name          character identifier of the node
     */
    public Node(int newLocationX, int newLocationY, String name){
        nodeName    = name;
        locationX   = newLocationX;
        locationY   = newLocationY;
    }
    
    /**
     * Getter for location on the x axis
     * @return integer locationX
     */
    public int getLocationX() {
        return  locationX;
    }
    /**
     * Getter for location on the y axis
     * @return integer locationY
     */    
    public int getLocationY() {
        return  locationY;
    }
    /**
     * Getter for the character name of the node
     * @return character nodeName
     */    
    public String getNodeName() {
        return  nodeName;
    }
    
}
